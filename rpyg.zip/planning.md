*turn based combat between player and Npcs

different actions:
    *attacks
    *defense
    *run away
    base_dodge

advantage and disatvantage system based on character type:
*equipping items
*consumables
*stattus effects (states)
saving

maybe:
    shops
    quests
    diferent locations:
        path system (choices of where to go, like inscryption's maps)
    character dialogue