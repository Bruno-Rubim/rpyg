from model.player import Player

class Save:
    def __init__(self, player: Player):
        self.player = player